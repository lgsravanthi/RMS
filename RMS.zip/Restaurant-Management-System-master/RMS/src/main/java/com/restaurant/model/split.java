package com.restaurant.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class split {
	
	private Float split;
	private Float split1;
	private Float split2;
	private Float split3;
	private Float split4;
	private Float split5;
	private Integer splitnumber;
}
